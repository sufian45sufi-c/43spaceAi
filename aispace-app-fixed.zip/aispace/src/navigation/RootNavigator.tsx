import React, { useEffect, useState } from 'react';
import { NavigationContainer, NavigationProp } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../store/authStore';
import { useProjectStore } from '../store/projectStore';
import { COLORS, SIZES } from '../constants/theme';

// Screens
import { SplashScreen } from '../screens/SplashScreen';
import { LoginScreen } from '../screens/LoginScreen';
import { SignUpScreen } from '../screens/SignUpScreen';
import { DashboardScreen } from '../screens/DashboardScreen';
import { ProjectsListScreen } from '../screens/ProjectsListScreen';
import { NewProjectScreen } from '../screens/NewProjectScreen';
import { ProjectDetailScreen } from '../screens/ProjectDetailScreen';
import { ChatScreen } from '../screens/ChatScreen';
import { ProfileScreen } from '../screens/ProfileScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

type RootStackParamList = {
  Dashboard: undefined;
  ProjectsList: undefined;
  NewProject: undefined;
  ProjectDetail: undefined;
  Chat: undefined;
  Profile: undefined;
};

type NavigationProps = NavigationProp<RootStackParamList>;

export const RootNavigator: React.FC = () => {
  const { user, loading, logout } = useAuthStore();
  const { currentProject, setCurrentProject } = useProjectStore();
  const [showSplash, setShowSplash] = useState(true);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  if (showSplash) {
    return (
      <SplashScreen
        onFinish={() => {
          setShowSplash(false);
        }}
      />
    );
  }

  if (loading) {
    return null;
  }

  if (!user) {
    return (
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          {authMode === 'login' ? (
            <Stack.Screen
              name="Login"
              options={{ animationEnabled: false } as any}
              children={() => (
                <LoginScreen
                  onLoginSuccess={() => {}}
                  onNavigateToSignUp={() => setAuthMode('signup')}
                />
              )}
            />
          ) : (
            <Stack.Screen
              name="SignUp"
              options={{ animationEnabled: false } as any}
              children={() => (
                <SignUpScreen
                  onSignUpSuccess={() => {}}
                  onNavigateToLogin={() => setAuthMode('login')}
                />
              )}
            />
          )}
        </Stack.Navigator>
      </NavigationContainer>
    );
  }

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarStyle: {
            backgroundColor: COLORS.surfaceElevated,
            borderTopColor: COLORS.border,
            borderTopWidth: 2,
            height: 56,
          },
          tabBarActiveTintColor: COLORS.accentCyan,
          tabBarInactiveTintColor: COLORS.textMuted,
        }}
      >
        <Tab.Screen
          name="Dashboard"
          options={{
            tabBarIcon: ({ color }) => <Ionicons name="home-outline" size={SIZES.ghostSmall} color={color} />,
            tabBarLabel: 'HOME',
          }}
          children={({ navigation }: { navigation: NavigationProps }) => (
            <Stack.Navigator screenOptions={{ headerShown: false }}>
              <Stack.Screen
                name="DashboardScreen"
                children={() => (
                  <DashboardScreen
                    onNavigateToProjects={() => (navigation as any).navigate('ProjectsList')}
                    onNavigateToNewProject={() => (navigation as any).navigate('NewProject')}
                  />
                )}
              />
              <Stack.Screen
                name="ProjectsList"
                children={() => (
                  <ProjectsListScreen
                    onNavigateToNewProject={() => (navigation as any).navigate('NewProject')}
                    onSelectProject={(projectId: string) => {
                      setCurrentProject(projectId as any);
                      (navigation as any).navigate('ProjectDetail');
                    }}
                  />
                )}
              />
              <Stack.Screen
                name="NewProject"
                children={() => (
                  <NewProjectScreen
                    onClose={() => (navigation as any).goBack()}
                    onProjectCreated={(projectId: string) => {
                      setCurrentProject(projectId as any);
                      (navigation as any).navigate('Chat');
                    }}
                  />
                )}
              />
              <Stack.Screen
                name="ProjectDetail"
                children={() => (
                  <ProjectDetailScreen
                    projectId={currentProject?.id || ''}
                    onNavigateBack={() => (navigation as any).goBack()}
                    onNavigateToChat={() => (navigation as any).navigate('Chat')}
                    onNavigateToSkills={() => {}}
                  />
                )}
              />
              <Stack.Screen
                name="Chat"
                children={() => (
                  <ChatScreen
                    projectId={currentProject?.id || ''}
                    onNavigateBack={() => (navigation as any).goBack()}
                  />
                )}
              />
            </Stack.Navigator>
          )}
        />

        <Tab.Screen
          name="Profile"
          options={{
            tabBarIcon: ({ color }) => <Ionicons name="person-outline" size={SIZES.ghostSmall} color={color} />,
            tabBarLabel: 'PROFILE',
          }}
          children={() => (
            <ProfileScreen
              onLogout={() => {
                logout();
              }}
            />
          )}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default RootNavigator;
