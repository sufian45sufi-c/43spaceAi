import {
  collection,
  addDoc,
  query,
  where,
  getDocs,
  orderBy,
  deleteDoc,
  doc,
} from 'firebase/firestore';
import { db } from '../firebase.config';
import { Message } from '../types';

export const messagesService = {
  async addMessage(
    projectId: string,
    userId: string,
    role: 'user' | 'assistant',
    content: string
  ): Promise<Message> {
    const docRef = await addDoc(collection(db, 'messages'), {
      projectId,
      userId,
      role,
      content,
      createdAt: Date.now(),
    });

    return {
      id: docRef.id,
      projectId,
      userId,
      role,
      content,
      createdAt: Date.now(),
    };
  },

  async getMessagesByProject(projectId: string): Promise<Message[]> {
    const q = query(
      collection(db, 'messages'),
      where('projectId', '==', projectId),
      orderBy('createdAt', 'asc')
    );

    const snapshot = await getDocs(q);
    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as Message[];
  },

  async deleteMessagesByProject(projectId: string): Promise<void> {
    const q = query(collection(db, 'messages'), where('projectId', '==', projectId));
    const snapshot = await getDocs(q);

    for (const docSnapshot of snapshot.docs) {
      await deleteDoc(doc(db, 'messages', docSnapshot.id));
    }
  },
};
