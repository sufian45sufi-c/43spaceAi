import { Project, Message, UserSettings } from '../types';
import { Skill } from '../constants/skills';
import { buildSystemPrompt } from '../utils/buildSystemPrompt';
import { geminiService } from './gemini.service';

export const aiService = {
  async sendMessage(
    userMessage: string,
    project: Project,
    activeSkills: Skill[],
    messageHistory: Message[],
    settings: UserSettings
  ): Promise<string> {
    const systemPrompt = buildSystemPrompt(project, activeSkills);
    const messages = [
      ...messageHistory.map((m) => ({ role: m.role, content: m.content })),
      { role: 'user', content: userMessage },
    ];

    // Try Ollama first (local)
    try {
      const url = settings.ollamaUrl || 'http://localhost:11434';
      const model = settings.preferredModel || 'gemma2';

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      const res = await fetch(`${url}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          messages: [{ role: 'system', content: systemPrompt }, ...messages],
          stream: false,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!res.ok) throw new Error('OLLAMA_FAILED');

      const data = await res.json();
      return data.message.content;
    } catch (error) {
      // Silent fallback to Gemini
      try {
        return await geminiService.sendMessage(systemPrompt, messages);
      } catch (geminiError) {
        throw new Error('NO_AI_AVAILABLE');
      }
    }
  },
};
