import * as SecureStore from 'expo-secure-store';

export const geminiService = {
  async sendMessage(systemPrompt: string, messages: Array<{ role: string; content: string }>): Promise<string> {
    const apiKey = await SecureStore.getItemAsync('gemini_api_key');
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY_NOT_SET');
    }

    const formattedMessages = [
      {
        role: 'user',
        parts: [{ text: `${systemPrompt}\n\n${messages.map((m) => `${m.role}: ${m.content}`).join('\n')}` }],
      },
    ];

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: formattedMessages,
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`GEMINI_API_ERROR: ${response.statusText}`);
    }

    const data = await response.json();

    if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
      throw new Error('GEMINI_INVALID_RESPONSE');
    }

    return data.candidates[0].content.parts[0].text;
  },

  async setApiKey(key: string): Promise<void> {
    await SecureStore.setItemAsync('gemini_api_key', key);
  },

  async getApiKey(): Promise<string | null> {
    return await SecureStore.getItemAsync('gemini_api_key');
  },

  async clearApiKey(): Promise<void> {
    await SecureStore.deleteItemAsync('gemini_api_key');
  },
};
