import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebase.config';
import { User } from '../types';
import { DEFAULT_SKILLS } from '../constants/skills';

export const authService = {
  async signUp(email: string, password: string, displayName: string): Promise<User> {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Update display name
    await updateProfile(user, { displayName });

    // Create user document in Firestore
    const userData: User = {
      uid: user.uid,
      email: user.email || '',
      displayName: displayName,
      createdAt: Date.now(),
      ollamaUrl: 'http://localhost:11434',
      preferredModel: 'gemma2',
    };

    await setDoc(doc(db, 'users', user.uid), userData);

    // Seed default skills
    const skillsRef = doc(db, 'skills', 'default');
    const skillsDoc = await getDoc(skillsRef);
    if (!skillsDoc.exists()) {
      for (const skill of DEFAULT_SKILLS) {
        await setDoc(doc(db, 'skills', skill.id), skill);
      }
    }

    return userData;
  },

  async login(email: string, password: string): Promise<User> {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Get user document from Firestore
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (!userDoc.exists()) {
      throw new Error('USER_NOT_FOUND');
    }

    return userDoc.data() as User;
  },

  async logout(): Promise<void> {
    await signOut(auth);
  },

  async getCurrentUser(): Promise<User | null> {
    const user = auth.currentUser;
    if (!user) return null;

    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (!userDoc.exists()) return null;

    return userDoc.data() as User;
  },
};
