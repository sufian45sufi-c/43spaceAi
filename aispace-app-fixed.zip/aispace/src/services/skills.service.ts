import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../firebase.config';
import { Skill } from '../constants/skills';

export const skillsService = {
  async getAllSkills(): Promise<Skill[]> {
    const q = query(collection(db, 'skills'));
    const snapshot = await getDocs(q);

    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as Skill[];
  },

  async getSkillsByIds(skillIds: string[]): Promise<Skill[]> {
    if (skillIds.length === 0) return [];

    const allSkills = await this.getAllSkills();
    return allSkills.filter((skill) => skillIds.includes(skill.id));
  },

  async getSkillsByCategory(category: string): Promise<Skill[]> {
    const q = query(collection(db, 'skills'), where('category', '==', category));
    const snapshot = await getDocs(q);

    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as Skill[];
  },
};
