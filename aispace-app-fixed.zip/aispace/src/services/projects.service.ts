import {
  collection,
  addDoc,
  query,
  where,
  getDocs,
  getDoc,
  updateDoc,
  deleteDoc,
  doc,
  orderBy,
} from 'firebase/firestore';
import { db } from '../firebase.config';
import { Project } from '../types';

export const projectsService = {
  async createProject(userId: string, project: Omit<Project, 'id' | 'userId'>): Promise<Project> {
    const docRef = await addDoc(collection(db, 'projects'), {
      ...project,
      userId,
    });

    return {
      ...project,
      id: docRef.id,
      userId,
    } as Project;
  },

  async getProjectsByUser(userId: string): Promise<Project[]> {
    const q = query(
      collection(db, 'projects'),
      where('userId', '==', userId),
      orderBy('updatedAt', 'desc')
    );

    const snapshot = await getDocs(q);
    return snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as Project[];
  },

  async getProject(projectId: string): Promise<Project | null> {
    const docRef = doc(db, 'projects', projectId);
    const docSnapshot = await getDoc(docRef);

    if (!docSnapshot.exists()) return null;

    return {
      id: docSnapshot.id,
      ...docSnapshot.data(),
    } as Project;
  },

  async updateProject(projectId: string, updates: Partial<Project>): Promise<void> {
    const docRef = doc(db, 'projects', projectId);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: Date.now(),
    });
  },

  async deleteProject(projectId: string): Promise<void> {
    const docRef = doc(db, 'projects', projectId);
    await deleteDoc(docRef);
  },

  async updateActiveSkills(projectId: string, skillIds: string[]): Promise<void> {
    const docRef = doc(db, 'projects', projectId);
    await updateDoc(docRef, {
      activeSkills: skillIds,
      updatedAt: Date.now(),
    });
  },
};
