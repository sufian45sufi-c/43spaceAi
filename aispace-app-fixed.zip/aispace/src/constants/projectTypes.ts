export const PROJECT_TYPES = [
  'app',
  'website',
  'game',
  'writing',
  'research',
  'other',
] as const;

export type ProjectType = (typeof PROJECT_TYPES)[number];

export const PROJECT_TYPE_EMOJIS: Record<ProjectType, string> = {
  app: '📱',
  website: '🌐',
  game: '🎮',
  writing: '✍️',
  research: '🔬',
  other: '✨',
};
