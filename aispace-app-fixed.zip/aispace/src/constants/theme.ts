export const COLORS = {
  bg: '#0a0a1f',
  surface: '#141432',
  surfaceElevated: '#1e1e4a',
  border: '#2d2d5a',
  primary: '#7c3aed',
  primaryDark: '#3b1d80',
  textPrimary: '#f5f5ff',
  textMuted: '#8a8ab5',
  textAccent: '#a5f3fc',
  accentCyan: '#22d3ee',
  accentGreen: '#4ade80',
  accentRed: '#f87171',
} as const;

export const FONTS = {
  pressStart2P: 'PressStart2P_400Regular',
} as const;

export const SIZES = {
  textTiny: 8,
  textSmall: 10,
  textBody: 12,
  textHeader: 16,
  buttonHeight: 44,
  inputHeight: 44,
  ghostTiny: 16,
  ghostSmall: 24,
  ghostMedium: 48,
  ghostLarge: 96,
} as const;

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
} as const;
