export interface Skill {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  promptInjection: string;
}

export const SKILL_CATEGORIES = [
  'All',
  'Planning',
  'Coding',
  'Design',
  'Research',
  'Writing',
] as const;

export const DEFAULT_SKILLS: Skill[] = [
  {
    id: 'planning',
    name: 'Project Planner',
    description: 'Breaks the project into milestones and tasks.',
    category: 'Planning',
    icon: 'list',
    promptInjection: 'Break down complex requests into milestones and tasks.',
  },
  {
    id: 'coding',
    name: 'Code Helper',
    description: 'Offers code snippets and reviews.',
    category: 'Coding',
    icon: 'code-slash',
    promptInjection: 'Suggest code snippets and review code for issues.',
  },
  {
    id: 'design',
    name: 'Design Critic',
    description: 'Reviews UI/UX choices.',
    category: 'Design',
    icon: 'color-palette',
    promptInjection: 'Critique UI/UX choices and propose improvements.',
  },
  {
    id: 'research',
    name: 'Research Assistant',
    description: 'Surfaces references and prior art.',
    category: 'Research',
    icon: 'search',
    promptInjection: 'Surface relevant references and prior art for the topic.',
  },
  {
    id: 'writing',
    name: 'Writing Coach',
    description: 'Improves clarity and tone of written content.',
    category: 'Writing',
    icon: 'create',
    promptInjection: 'Improve the clarity, tone, and structure of writing.',
  },
];
