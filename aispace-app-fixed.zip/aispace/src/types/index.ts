import { Skill } from '../constants/skills';
import { ProjectType } from '../constants/projectTypes';

export interface User {
  uid: string;
  email: string;
  displayName: string;
  createdAt: number;
  ollamaUrl: string;
  preferredModel: string;
}

export interface Project {
  id: string;
  userId: string;
  title: string;
  description: string;
  type: ProjectType;
  createdAt: number;
  updatedAt: number;
  activeSkills: string[];
}

export interface Message {
  id: string;
  projectId: string;
  userId: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: number;
}

export interface UserSettings {
  ollamaUrl: string;
  preferredModel: string;
  geminiApiKey?: string;
}

export interface AIResponse {
  content: string;
  model: string;
  source: 'ollama' | 'gemini';
}

export type AuthState = {
  user: User | null;
  loading: boolean;
  error: string | null;
};

export type ProjectsState = {
  projects: Project[];
  currentProject: Project | null;
  loading: boolean;
  error: string | null;
};

export type SettingsState = {
  settings: UserSettings;
  loading: boolean;
  error: string | null;
};
