import { useEffect } from 'react';
import { useProjectStore } from '../store/projectStore';
import { projectsService } from '../services/projects.service';
import { Project } from '../types';

export const useProjects = (userId: string | null) => {
  const { projects, loading, error, setProjects, setLoading, setError } = useProjectStore();

  useEffect(() => {
    if (!userId) {
      setProjects([]);
      return;
    }

    const loadProjects = async () => {
      setLoading(true);
      try {
        const data = await projectsService.getProjectsByUser(userId);
        setProjects(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'PROJECTS_LOAD_ERROR');
      } finally {
        setLoading(false);
      }
    };

    loadProjects();
  }, [userId]);

  const createProject = async (project: Omit<Project, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
    if (!userId) throw new Error('USER_NOT_AUTHENTICATED');
    const newProject = await projectsService.createProject(userId, {
      ...project,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
    return newProject;
  };

  const deleteProject = async (projectId: string) => {
    await projectsService.deleteProject(projectId);
  };

  return { projects, loading, error, createProject, deleteProject };
};
