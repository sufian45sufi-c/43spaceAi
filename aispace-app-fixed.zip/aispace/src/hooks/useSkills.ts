import { useEffect, useState } from 'react';
import { skillsService } from '../services/skills.service';
import { Skill } from '../constants/skills';

export const useSkills = () => {
  const [allSkills, setAllSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadSkills = async () => {
      setLoading(true);
      try {
        const data = await skillsService.getAllSkills();
        setAllSkills(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'SKILLS_LOAD_ERROR');
      } finally {
        setLoading(false);
      }
    };

    loadSkills();
  }, []);

  const getActiveSkills = (skillIds: string[]): Skill[] => {
    return allSkills.filter((skill) => skillIds.includes(skill.id));
  };

  const getSkillsByCategory = (category: string): Skill[] => {
    if (category === 'All') return allSkills;
    return allSkills.filter((skill) => skill.category === category);
  };

  return { allSkills, loading, error, getActiveSkills, getSkillsByCategory };
};
