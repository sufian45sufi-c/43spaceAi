import { useEffect } from 'react';
import { useAuthStore } from '../store/authStore';
import { authService } from '../services/auth.service';
import { auth } from '../firebase.config';

export const useAuth = () => {
  const { user, loading, error, setUser, setLoading, setError } = useAuthStore();

  useEffect(() => {
    setLoading(true);

    const unsubscribe = auth.onAuthStateChanged(async (firebaseUser) => {
      try {
        if (firebaseUser) {
          const userData = await authService.getCurrentUser();
          setUser(userData);
        } else {
          setUser(null);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'AUTH_ERROR');
      } finally {
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  return { user, loading, error, setUser, setError };
};
