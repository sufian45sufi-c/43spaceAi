import { useEffect, useState } from 'react';
import { messagesService } from '../services/messages.service';
import { Message } from '../types';

export const useMessages = (projectId: string | null) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!projectId) {
      setMessages([]);
      return;
    }

    const loadMessages = async () => {
      setLoading(true);
      try {
        const data = await messagesService.getMessagesByProject(projectId);
        setMessages(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'MESSAGES_LOAD_ERROR');
      } finally {
        setLoading(false);
      }
    };

    loadMessages();
  }, [projectId]);

  const addMessage = async (userId: string, role: 'user' | 'assistant', content: string) => {
    if (!projectId) throw new Error('PROJECT_NOT_SET');
    const message = await messagesService.addMessage(projectId, userId, role, content);
    setMessages((prev) => [...prev, message]);
    return message;
  };

  return { messages, loading, error, addMessage };
};
