/**
 * Firebase Configuration for AIspace
 *
 * IMPORTANT: You must fill in your Firebase credentials here.
 *
 * To get your credentials:
 * 1. Go to https://console.firebase.google.com
 * 2. Create a new project or select an existing one
 * 3. Go to Project Settings (gear icon)
 * 4. Under "Your apps", select or create a web app
 * 5. Copy the config object below
 *
 * The config object should look like:
 * {
 *   apiKey: "YOUR_API_KEY",
 *   authDomain: "your-project.firebaseapp.com",
 *   projectId: "your-project",
 *   storageBucket: "your-project.appspot.com",
 *   messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
 *   appId: "YOUR_APP_ID"
 * }
 */

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// TODO: Replace with your Firebase config
const firebaseConfig = {
  apiKey: 'YOUR_API_KEY_HERE',
  authDomain: 'YOUR_AUTH_DOMAIN_HERE',
  projectId: 'YOUR_PROJECT_ID_HERE',
  storageBucket: 'YOUR_STORAGE_BUCKET_HERE',
  messagingSenderId: 'YOUR_MESSAGING_SENDER_ID_HERE',
  appId: 'YOUR_APP_ID_HERE',
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app);

export default app;
