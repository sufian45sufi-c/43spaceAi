import React from 'react';
import { Pressable, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';

interface PixelButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'danger';
  size?: 'small' | 'medium' | 'large';
  fullWidth?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
}

export const PixelButton: React.FC<PixelButtonProps> = ({
  label,
  onPress,
  variant = 'primary',
  size = 'medium',
  fullWidth = false,
  disabled = false,
  style,
}) => {
  const getBackgroundColor = () => {
    if (disabled) return COLORS.textMuted;
    switch (variant) {
      case 'primary':
        return COLORS.primary;
      case 'secondary':
        return 'transparent';
      case 'danger':
        return COLORS.accentRed;
      default:
        return COLORS.primary;
    }
  };

  const getBorderColor = () => {
    switch (variant) {
      case 'secondary':
        return COLORS.accentCyan;
      default:
        return 'transparent';
    }
  };

  const getTextColor = () => {
    if (disabled) return COLORS.textMuted;
    switch (variant) {
      case 'secondary':
        return COLORS.accentCyan;
      case 'primary':
      case 'danger':
        return COLORS.textPrimary;
      default:
        return COLORS.textPrimary;
    }
  };

  const getHeight = () => {
    switch (size) {
      case 'small':
        return 40;
      case 'medium':
        return SIZES.buttonHeight;
      case 'large':
        return 64;
      default:
        return SIZES.buttonHeight;
    }
  };

  const containerStyle: ViewStyle = {
    height: getHeight(),
    backgroundColor: getBackgroundColor(),
    borderWidth: 2,
    borderColor: getBorderColor(),
    borderRightWidth: 4,
    borderBottomWidth: 4,
    borderRightColor: variant === 'secondary' ? COLORS.accentCyan : COLORS.primaryDark,
    borderBottomColor: variant === 'secondary' ? COLORS.accentCyan : COLORS.primaryDark,
    paddingHorizontal: SPACING.md,
    justifyContent: 'center',
    alignItems: 'center',
    opacity: disabled ? 0.6 : 1,
  };

  const textStyle: TextStyle = {
    fontFamily: FONTS.pressStart2P,
    fontSize: SIZES.textSmall,
    color: getTextColor(),
    textTransform: 'uppercase',
  };

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        containerStyle,
        fullWidth && { flex: 1 },
        pressed && !disabled && { transform: [{ scale: 0.97 }] },
        style,
      ]}
    >
      <Text style={textStyle}>{label}</Text>
    </Pressable>
  );
};

export default PixelButton;
