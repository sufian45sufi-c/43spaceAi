import React from 'react';
import { View, Text, ViewStyle } from 'react-native';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';

interface PixelBadgeProps {
  label: string;
  bgColor?: string;
  textColor?: string;
  style?: ViewStyle;
}

export const PixelBadge: React.FC<PixelBadgeProps> = ({
  label,
  bgColor = COLORS.primary,
  textColor = COLORS.textPrimary,
  style,
}) => {
  return (
    <View
      style={[
        {
          backgroundColor: bgColor,
          borderWidth: 1,
          borderColor: textColor,
          paddingHorizontal: SPACING.sm,
          paddingVertical: SPACING.xs,
          alignSelf: 'flex-start',
        },
        style,
      ]}
    >
      <Text
        style={{
          fontFamily: FONTS.pressStart2P,
          fontSize: SIZES.textTiny,
          color: textColor,
          textTransform: 'uppercase',
        }}
      >
        {label}
      </Text>
    </View>
  );
};

export default PixelBadge;
