import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Project } from '../types';
import { PixelCard } from './PixelCard';
import { PixelBadge } from './PixelBadge';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { formatDate } from '../utils/formatDate';

interface ProjectCardProps {
  project: Project;
  onPress: () => void;
  onDelete?: () => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project, onPress, onDelete }) => {
  return (
    <Pressable onPress={onPress}>
      <PixelCard
        bgColor={COLORS.surfaceElevated}
        borderColor={COLORS.border}
        shadowColor={COLORS.primaryDark}
      >
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: SPACING.sm }}>
          <PixelBadge label={project.type.toUpperCase()} bgColor={COLORS.primary} />
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textTiny,
              color: COLORS.textMuted,
              textTransform: 'uppercase',
            }}
          >
            {formatDate(project.updatedAt)}
          </Text>
        </View>

        <Text
          style={{
            fontFamily: FONTS.pressStart2P,
            fontSize: SIZES.textSmall,
            color: COLORS.textPrimary,
            textTransform: 'uppercase',
            marginBottom: SPACING.xs,
          }}
        >
          {project.title}
        </Text>

        <Text
          numberOfLines={2}
          style={{
            fontFamily: FONTS.pressStart2P,
            fontSize: SIZES.textTiny,
            color: COLORS.textMuted,
            textTransform: 'uppercase',
            marginBottom: SPACING.md,
          }}
        >
          {project.description}
        </Text>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <View style={{ flexDirection: 'row', gap: SPACING.xs }}>
            {project.activeSkills.slice(0, 3).map((skillId) => (
              <PixelBadge key={skillId} label="●" bgColor={COLORS.accentGreen} />
            ))}
          </View>
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textSmall,
              color: COLORS.textAccent,
            }}
          >
            ►
          </Text>
        </View>
      </PixelCard>
    </Pressable>
  );
};

export default ProjectCard;
