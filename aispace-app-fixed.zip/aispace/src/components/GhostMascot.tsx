import React from 'react';
import { Text, StyleProp, TextStyle } from 'react-native';
import { COLORS, FONTS } from '../constants/theme';

interface GhostMascotProps {
  size?: number;
  style?: StyleProp<TextStyle>;
  color?: string;
}

export const GhostMascot: React.FC<GhostMascotProps> = ({ size = 48, style, color = COLORS.primary }) => {
  return (
    <Text
      style={[
        {
          fontFamily: FONTS.pressStart2P,
          fontSize: size,
          lineHeight: size * 1.1,
          color,
          textAlign: 'center',
        },
        style,
      ]}
    >
      👻
    </Text>
  );
};

export default GhostMascot;
