import React from 'react';
import { Pressable, View, Text, ViewStyle } from 'react-native';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';

interface PixelToggleProps {
  value: boolean;
  onToggle: (value: boolean) => void;
  style?: ViewStyle;
}

export const PixelToggle: React.FC<PixelToggleProps> = ({ value, onToggle, style }) => {
  return (
    <Pressable
      onPress={() => onToggle(!value)}
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          gap: SPACING.sm,
        },
        style,
      ]}
    >
      <View
        style={{
          width: 32,
          height: 16,
          backgroundColor: value ? COLORS.accentGreen : COLORS.border,
          borderWidth: 1,
          borderColor: value ? COLORS.accentGreen : COLORS.textMuted,
          borderRightWidth: 2,
          borderBottomWidth: 2,
          borderRightColor: value ? COLORS.accentGreen : COLORS.textMuted,
          borderBottomColor: value ? COLORS.accentGreen : COLORS.textMuted,
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <Text
          style={{
            fontFamily: FONTS.pressStart2P,
            fontSize: SIZES.textTiny,
            color: value ? COLORS.bg : COLORS.textMuted,
            textTransform: 'uppercase',
          }}
        >
          {value ? '■' : '□'}
        </Text>
      </View>
    </Pressable>
  );
};

export default PixelToggle;
