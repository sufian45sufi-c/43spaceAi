import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Skill } from '../constants/skills';
import { PixelCard } from './PixelCard';
import { PixelToggle } from './PixelToggle';
import { PixelBadge } from './PixelBadge';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';

interface SkillCardProps {
  skill: Skill;
  isActive: boolean;
  onToggle: (active: boolean) => void;
}

export const SkillCard: React.FC<SkillCardProps> = ({ skill, isActive, onToggle }) => {
  return (
    <PixelCard
      bgColor={isActive ? COLORS.surfaceElevated : COLORS.surface}
      borderColor={isActive ? COLORS.accentGreen : COLORS.border}
      shadowColor={isActive ? COLORS.accentGreen : COLORS.primaryDark}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: SPACING.md }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: SPACING.sm, flex: 1 }}>
          <Ionicons name={skill.icon as any} size={SIZES.ghostSmall} color={COLORS.textAccent} />
          {isActive && <PixelBadge label="ACTIVE" bgColor={COLORS.accentGreen} textColor={COLORS.bg} />}
        </View>
      </View>

      <Text
        style={{
          fontFamily: FONTS.pressStart2P,
          fontSize: SIZES.textSmall,
          color: COLORS.textPrimary,
          textTransform: 'uppercase',
          marginBottom: SPACING.xs,
        }}
      >
        {skill.name}
      </Text>

      <Text
        numberOfLines={2}
        style={{
          fontFamily: FONTS.pressStart2P,
          fontSize: SIZES.textTiny,
          color: COLORS.textMuted,
          textTransform: 'uppercase',
          marginBottom: SPACING.md,
        }}
      >
        {skill.description}
      </Text>

      <PixelToggle value={isActive} onToggle={onToggle} />
    </PixelCard>
  );
};

export default SkillCard;
