import React, { useState, useMemo } from 'react';
import { View, Text, FlatList, TextInput } from 'react-native';
import BottomSheet from '@gorhom/bottom-sheet';
import { GhostMascot } from './GhostMascot';
import { PixelButton } from './PixelButton';
import { PixelBadge } from './PixelBadge';
import { SkillCard } from './SkillCard';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { SKILL_CATEGORIES } from '../constants/skills';
import { Skill } from '../constants/skills';

interface SkillLibrarySheetProps {
  isOpen: boolean;
  allSkills: Skill[];
  activeSkillIds: string[];
  onSkillToggle: (skillId: string, active: boolean) => void;
  onClose: () => void;
}

export const SkillLibrarySheet: React.FC<SkillLibrarySheetProps> = ({
  isOpen,
  allSkills,
  activeSkillIds,
  onSkillToggle,
  onClose,
}) => {
  const [searchText, setSearchText] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredSkills = useMemo(() => {
    return allSkills.filter((skill) => {
      const matchesSearch = skill.name.toLowerCase().includes(searchText.toLowerCase()) ||
        skill.description.toLowerCase().includes(searchText.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || skill.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [allSkills, searchText, selectedCategory]);

  const activeCount = activeSkillIds.length;

  if (!isOpen) return null;

  return (
    <BottomSheet snapPoints={['70%']} onClose={onClose} enablePanDownToClose>
      <View style={{ flex: 1, backgroundColor: COLORS.bg, paddingHorizontal: SPACING.md }}>
        {/* Drag Handle */}
        <View style={{ alignItems: 'center', marginVertical: SPACING.md }}>
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textSmall,
              color: COLORS.border,
            }}
          >
            ■ ■ ■
          </Text>
        </View>

        {/* Header */}
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: SPACING.md }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: SPACING.sm }}>
            <GhostMascot size={SIZES.ghostSmall} />
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textSmall,
                color: COLORS.textPrimary,
                textTransform: 'uppercase',
              }}
            >
              ░░ SKILL LIBRARY ░░
            </Text>
          </View>
          <PixelBadge label={`${activeCount} ACTIVE`} bgColor={COLORS.accentCyan} textColor={COLORS.bg} />
        </View>

        {/* Search */}
        <TextInput
          placeholder="► SEARCH SKILLS..."
          placeholderTextColor={COLORS.textMuted}
          value={searchText}
          onChangeText={setSearchText}
          style={{
            fontFamily: FONTS.pressStart2P,
            fontSize: SIZES.textSmall,
            color: COLORS.textPrimary,
            backgroundColor: COLORS.surface,
            borderWidth: 2,
            borderColor: COLORS.accentCyan,
            borderRightWidth: 3,
            borderBottomWidth: 3,
            borderRightColor: COLORS.primaryDark,
            borderBottomColor: COLORS.primaryDark,
            paddingHorizontal: SPACING.sm,
            paddingVertical: SPACING.xs,
            marginBottom: SPACING.md,
            textTransform: 'uppercase',
          }}
        />

        {/* Category Tabs */}
        <FlatList
          data={SKILL_CATEGORIES}
          keyExtractor={(item) => item}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ marginBottom: SPACING.md, gap: SPACING.sm }}
          renderItem={({ item }) => (
            <PixelButton
              label={item.toUpperCase()}
              onPress={() => setSelectedCategory(item)}
              variant={selectedCategory === item ? 'primary' : 'secondary'}
              size="small"
            />
          )}
        />

        {/* Skills Grid */}
        <FlatList
          data={filteredSkills}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={{ gap: SPACING.md }}
          contentContainerStyle={{ gap: SPACING.md, paddingBottom: SPACING.lg }}
          renderItem={({ item }) => (
            <View style={{ flex: 1 }}>
              <SkillCard
                skill={item}
                isActive={activeSkillIds.includes(item.id)}
                onToggle={(active) => onSkillToggle(item.id, active)}
              />
            </View>
          )}
        />
      </View>
    </BottomSheet>
  );
};

export default SkillLibrarySheet;
