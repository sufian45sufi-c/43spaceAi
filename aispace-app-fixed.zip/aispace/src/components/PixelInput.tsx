import React from 'react';
import { TextInput, View, ViewStyle, TextInputProps } from 'react-native';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';

interface PixelInputProps extends TextInputProps {
  containerStyle?: ViewStyle;
  multiline?: boolean;
  rows?: number;
}

export const PixelInput: React.FC<PixelInputProps> = ({
  containerStyle,
  multiline = false,
  rows = 1,
  ...props
}) => {
  const height = multiline ? rows * 32 : SIZES.inputHeight;

  return (
    <View
      style={[
        {
          borderWidth: 2,
          borderColor: COLORS.accentCyan,
          borderRightWidth: 3,
          borderBottomWidth: 3,
          borderRightColor: COLORS.primaryDark,
          borderBottomColor: COLORS.primaryDark,
          backgroundColor: COLORS.surface,
          paddingHorizontal: SPACING.sm,
          paddingVertical: multiline ? SPACING.sm : 0,
          height: height,
          justifyContent: 'flex-start',
        },
        containerStyle,
      ]}
    >
      <TextInput
        {...props}
        multiline={multiline}
        numberOfLines={rows}
        placeholderTextColor={COLORS.textMuted}
        style={{
          fontFamily: FONTS.pressStart2P,
          fontSize: SIZES.textSmall,
          color: COLORS.textPrimary,
          flex: 1,
          textAlignVertical: 'top',
        }}
      />
    </View>
  );
};

export default PixelInput;
