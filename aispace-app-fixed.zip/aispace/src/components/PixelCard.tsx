import React from 'react';
import { View, ViewStyle } from 'react-native';
import { COLORS, SPACING } from '../constants/theme';

interface PixelCardProps {
  children: React.ReactNode;
  bgColor?: string;
  borderColor?: string;
  shadowColor?: string;
  padding?: number;
  style?: ViewStyle;
}

export const PixelCard: React.FC<PixelCardProps> = ({
  children,
  bgColor = COLORS.surfaceElevated,
  borderColor = COLORS.border,
  shadowColor = COLORS.primaryDark,
  padding = SPACING.md,
  style,
}) => {
  return (
    <View
      style={[
        {
          backgroundColor: bgColor,
          borderWidth: 2,
          borderColor: borderColor,
          borderRightWidth: 4,
          borderBottomWidth: 4,
          borderRightColor: shadowColor,
          borderBottomColor: shadowColor,
          padding: padding,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
};

export default PixelCard;
