import { create } from 'zustand';
import { UserSettings, SettingsState } from '../types';

interface SettingsStore extends SettingsState {
  setSettings: (settings: UserSettings) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  updateOllamaUrl: (url: string) => void;
  updatePreferredModel: (model: string) => void;
  updateGeminiApiKey: (key: string) => void;
}

export const useSettingsStore = create<SettingsStore>((set) => ({
  settings: {
    ollamaUrl: 'http://localhost:11434',
    preferredModel: 'gemma2',
    geminiApiKey: undefined,
  },
  loading: false,
  error: null,

  setSettings: (settings) => set({ settings }),
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),

  updateOllamaUrl: (url) =>
    set((state) => ({
      settings: { ...state.settings, ollamaUrl: url },
    })),

  updatePreferredModel: (model) =>
    set((state) => ({
      settings: { ...state.settings, preferredModel: model },
    })),

  updateGeminiApiKey: (key) =>
    set((state) => ({
      settings: { ...state.settings, geminiApiKey: key },
    })),
}));
