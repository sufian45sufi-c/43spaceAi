import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { GhostMascot } from '../components/GhostMascot';
import { PixelButton } from '../components/PixelButton';
import { PixelCard } from '../components/PixelCard';
import { PixelInput } from '../components/PixelInput';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { useAuthStore } from '../store/authStore';
import { useSettingsStore } from '../store/settingsStore';
import { geminiService } from '../services/gemini.service';
import { authService } from '../services/auth.service';

interface ProfileScreenProps {
  onLogout: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ onLogout }) => {
  const { user, logout } = useAuthStore();
  const { settings, updateOllamaUrl, updatePreferredModel, updateGeminiApiKey } = useSettingsStore();
  const [ollamaUrl, setOllamaUrl] = useState(settings.ollamaUrl);
  const [preferredModel, setPreferredModel] = useState(settings.preferredModel);
  const [geminiKey, setGeminiKey] = useState('');
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'online' | 'offline'>('idle');

  const handleTestConnection = async () => {
    setTestingConnection(true);
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      const res = await fetch(`${ollamaUrl}/api/tags`, {
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (res.ok) {
        setConnectionStatus('online');
        Alert.alert('SUCCESS', `● ONLINE / ${preferredModel.toUpperCase()} READY`);
      } else {
        setConnectionStatus('offline');
        Alert.alert('ERROR', '✕ OFFLINE');
      }
    } catch (error) {
      setConnectionStatus('offline');
      Alert.alert('ERROR', '✕ OFFLINE - CHECK YOUR OLLAMA SERVER URL');
    } finally {
      setTestingConnection(false);
    }
  };

  const handleSaveGeminiKey = async () => {
    if (!geminiKey.trim()) {
      Alert.alert('ERROR', 'PLEASE ENTER A GEMINI API KEY');
      return;
    }

    try {
      await geminiService.setApiKey(geminiKey);
      updateGeminiApiKey(geminiKey);
      setGeminiKey('');
      Alert.alert('SUCCESS', 'GEMINI API KEY SAVED');
    } catch (error) {
      Alert.alert('ERROR', 'FAILED_TO_SAVE_GEMINI_KEY');
    }
  };

  const handleLogout = async () => {
    Alert.alert('CONFIRM', 'ARE YOU SURE YOU WANT TO LOGOUT?', [
      { text: 'CANCEL', onPress: () => {} },
      {
        text: 'LOGOUT',
        onPress: async () => {
          try {
            await authService.logout();
            logout();
            onLogout();
          } catch (error) {
            Alert.alert('ERROR', 'FAILED_TO_LOGOUT');
          }
        },
      },
    ]);
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1, backgroundColor: COLORS.bg }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ paddingHorizontal: SPACING.md, paddingVertical: SPACING.lg }}>
          {/* Header */}
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textHeader,
              color: COLORS.primary,
              textTransform: 'uppercase',
              marginBottom: SPACING.lg,
              textAlign: 'center',
            }}
          >
            ■ PROFILE ■
          </Text>

          {/* Avatar */}
          <View style={{ alignItems: 'center', marginBottom: SPACING.lg }}>
            <GhostMascot size={SIZES.ghostLarge} />
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textSmall,
                color: COLORS.textPrimary,
                textTransform: 'uppercase',
                marginTop: SPACING.md,
              }}
            >
              {user?.displayName || 'USER'}
            </Text>
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textMuted,
                textTransform: 'uppercase',
              }}
            >
              {user?.email || 'EMAIL'}
            </Text>
          </View>

          {/* AI Engine Card */}
          <PixelCard
            bgColor={COLORS.surfaceElevated}
            borderColor={COLORS.border}
            shadowColor={COLORS.primaryDark}
            style={{ marginBottom: SPACING.lg }}
          >
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textSmall,
                color: COLORS.textPrimary,
                textTransform: 'uppercase',
                marginBottom: SPACING.md,
              }}
            >
              ░ AI ENGINE ░
            </Text>

            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              OLLAMA SERVER URL
            </Text>
            <PixelInput
              placeholder="HTTP://LOCALHOST:11434"
              value={ollamaUrl}
              onChangeText={setOllamaUrl}
              containerStyle={{ marginBottom: SPACING.md }}
            />

            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              AI MODEL
            </Text>
            <PixelInput
              placeholder="GEMMA2"
              value={preferredModel}
              onChangeText={setPreferredModel}
              containerStyle={{ marginBottom: SPACING.md }}
            />

            <PixelButton
              label={testingConnection ? 'TESTING...' : '► TEST CONNECTION'}
              onPress={handleTestConnection}
              disabled={testingConnection}
              fullWidth
              style={{ marginBottom: SPACING.md }}
            />

            {connectionStatus === 'online' && (
              <Text
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textTiny,
                  color: COLORS.accentGreen,
                  textTransform: 'uppercase',
                  textAlign: 'center',
                }}
              >
                ● ONLINE / {preferredModel.toUpperCase()} READY
              </Text>
            )}
            {connectionStatus === 'offline' && (
              <Text
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textTiny,
                  color: COLORS.accentRed,
                  textTransform: 'uppercase',
                  textAlign: 'center',
                }}
              >
                ✕ OFFLINE
              </Text>
            )}

            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textMuted,
                textTransform: 'uppercase',
                marginTop: SPACING.md,
              }}
            >
              ON DEVICE: USE LOCAL IP (E.G. HTTP://192.168.1.X:11434)
            </Text>
          </PixelCard>

          {/* Gemini Fallback Card */}
          <PixelCard
            bgColor={COLORS.surfaceElevated}
            borderColor={COLORS.border}
            shadowColor={COLORS.primaryDark}
            style={{ marginBottom: SPACING.lg }}
          >
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textSmall,
                color: COLORS.textPrimary,
                textTransform: 'uppercase',
                marginBottom: SPACING.md,
              }}
            >
              ░ CLOUD FALLBACK ░
            </Text>

            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              GEMINI API KEY
            </Text>
            <PixelInput
              placeholder="YOUR_GEMINI_API_KEY"
              value={geminiKey}
              onChangeText={setGeminiKey}
              secureTextEntry
              containerStyle={{ marginBottom: SPACING.md }}
            />

            <PixelButton
              label="► SAVE GEMINI KEY"
              onPress={handleSaveGeminiKey}
              fullWidth
            />
          </PixelCard>

          {/* Logout Button */}
          <PixelButton
            label="✕ LOGOUT"
            onPress={handleLogout}
            variant="danger"
            fullWidth
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default ProfileScreen;
