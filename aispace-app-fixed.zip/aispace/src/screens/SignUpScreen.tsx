import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { GhostMascot } from '../components/GhostMascot';
import { PixelButton } from '../components/PixelButton';
import { PixelCard } from '../components/PixelCard';
import { PixelInput } from '../components/PixelInput';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { authService } from '../services/auth.service';
import { useAuthStore } from '../store/authStore';

interface SignUpScreenProps {
  onSignUpSuccess: () => void;
  onNavigateToLogin: () => void;
}

export const SignUpScreen: React.FC<SignUpScreenProps> = ({ onSignUpSuccess, onNavigateToLogin }) => {
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { setUser, setError } = useAuthStore();

  const handleSignUp = async () => {
    if (!displayName || !email || !password || !confirmPassword) {
      Alert.alert('ERROR', 'PLEASE FILL IN ALL FIELDS');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('ERROR', 'PASSWORDS DO NOT MATCH');
      return;
    }

    if (password.length < 6) {
      Alert.alert('ERROR', 'PASSWORD MUST BE AT LEAST 6 CHARACTERS');
      return;
    }

    setLoading(true);
    try {
      const user = await authService.signUp(email, password, displayName);
      setUser(user);
      onSignUpSuccess();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'SIGNUP_FAILED';
      setError(errorMessage);
      Alert.alert('SIGNUP ERROR', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1, backgroundColor: COLORS.bg }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: SPACING.md }}>
          {/* Ghost Mascot */}
          <GhostMascot size={SIZES.ghostMedium} style={{ marginBottom: SPACING.lg }} />

          {/* Title */}
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textHeader,
              color: COLORS.primary,
              textTransform: 'uppercase',
              marginBottom: SPACING.lg,
              textAlign: 'center',
            }}
          >
            SIGN UP
          </Text>

          {/* Form Card */}
          <PixelCard
            bgColor={COLORS.surfaceElevated}
            borderColor={COLORS.accentCyan}
            shadowColor={COLORS.primaryDark}
            style={{ width: '100%', marginBottom: SPACING.lg }}
          >
            {/* Display Name Input */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              ◄ DISPLAY NAME
            </Text>
            <PixelInput
              placeholder="YOUR NAME"
              value={displayName}
              onChangeText={setDisplayName}
              editable={!loading}
              containerStyle={{ marginBottom: SPACING.md }}
            />

            {/* Email Input */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              ◄ EMAIL
            </Text>
            <PixelInput
              placeholder="YOUR@EMAIL.COM"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              editable={!loading}
              containerStyle={{ marginBottom: SPACING.md }}
            />

            {/* Password Input */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              ◄ PASSWORD
            </Text>
            <PixelInput
              placeholder="••••••••"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              editable={!loading}
              containerStyle={{ marginBottom: SPACING.md }}
            />

            {/* Confirm Password Input */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              ◄ CONFIRM PASSWORD
            </Text>
            <PixelInput
              placeholder="••••••••"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry
              editable={!loading}
              containerStyle={{ marginBottom: SPACING.lg }}
            />

            {/* Sign Up Button */}
            <PixelButton
              label={loading ? 'CREATING ACCOUNT...' : '► CREATE ACCOUNT'}
              onPress={handleSignUp}
              disabled={loading}
              fullWidth
            />
          </PixelCard>

          {/* Login Link */}
          <PixelButton
            label="ALREADY HAVE ACCOUNT? LOGIN ►"
            onPress={onNavigateToLogin}
            variant="secondary"
            disabled={loading}
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default SignUpScreen;
