import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { PixelButton } from '../components/PixelButton';
import { PixelCard } from '../components/PixelCard';
import { PixelInput } from '../components/PixelInput';
import { PixelBadge } from '../components/PixelBadge';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { PROJECT_TYPES, PROJECT_TYPE_EMOJIS } from '../constants/projectTypes';
import { useProjectStore } from '../store/projectStore';
import { useAuthStore } from '../store/authStore';
import { projectsService } from '../services/projects.service';

interface NewProjectScreenProps {
  onClose: () => void;
  onProjectCreated: (projectId: string) => void;
}

export const NewProjectScreen: React.FC<NewProjectScreenProps> = ({ onClose, onProjectCreated }) => {
  const [title, setTitle] = useState('');
  const [type, setType] = useState<string>(PROJECT_TYPES[0]);
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const { user } = useAuthStore();
  const { addProject } = useProjectStore();

  const handleCreate = async () => {
    if (!title.trim() || !description.trim()) {
      Alert.alert('ERROR', 'PLEASE FILL IN ALL FIELDS');
      return;
    }

    if (description.length > 500) {
      Alert.alert('ERROR', 'DESCRIPTION MUST BE 500 CHARACTERS OR LESS');
      return;
    }

    if (!user) {
      Alert.alert('ERROR', 'USER_NOT_AUTHENTICATED');
      return;
    }

    setLoading(true);
    try {
      const newProject = await projectsService.createProject(user.uid, {
        title: title.trim(),
        type: type as any,
        description: description.trim(),
        activeSkills: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });

      addProject(newProject);
      onProjectCreated(newProject.id);
      onClose();
    } catch (error) {
      Alert.alert('ERROR', error instanceof Error ? error.message : 'FAILED_TO_CREATE_PROJECT');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1, backgroundColor: COLORS.bg }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ paddingHorizontal: SPACING.md, paddingVertical: SPACING.lg }}>
          {/* Header */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.lg }}>
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textHeader,
                color: COLORS.primary,
                textTransform: 'uppercase',
              }}
            >
              ■ NEW PROJECT ■
            </Text>
            <PixelButton label="✕" onPress={onClose} size="small" disabled={loading} />
          </View>

          {/* Form Card */}
          <PixelCard
            bgColor={COLORS.surfaceElevated}
            borderColor={COLORS.accentCyan}
            shadowColor={COLORS.primaryDark}
            style={{ marginBottom: SPACING.lg }}
          >
            {/* Title */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              ◄ PROJECT TITLE
            </Text>
            <PixelInput
              placeholder="MY AWESOME PROJECT"
              value={title}
              onChangeText={setTitle}
              editable={!loading}
              containerStyle={{ marginBottom: SPACING.md }}
            />

            {/* Type */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              ◄ PROJECT TYPE
            </Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ gap: SPACING.sm, marginBottom: SPACING.md }}
            >
              {PROJECT_TYPES.map((t) => {
                const emoji = PROJECT_TYPE_EMOJIS[t];
                return (
                <PixelButton
                  key={t}
                  label={`${emoji} ${t.toUpperCase()}`}
                  onPress={() => setType(t)}
                  variant={type === t ? 'primary' : 'secondary'}
                  size="small"
                  disabled={loading}
                />
              );
              })}
            </ScrollView>

            {/* Description */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.xs,
              }}
            >
              ◄ DESCRIPTION
            </Text>
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textMuted,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              TELL THE AI ABOUT YOUR PROJECT
            </Text>
            <PixelInput
              placeholder="DESCRIBE YOUR PROJECT..."
              value={description}
              onChangeText={setDescription}
              multiline
              rows={5}
              editable={!loading}
              containerStyle={{ marginBottom: SPACING.sm }}
            />

            {/* Character Counter */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textMuted,
                textTransform: 'uppercase',
                textAlign: 'center',
                marginBottom: SPACING.lg,
              }}
            >
              ░░░ {description.length} / 500 ░░░
            </Text>

            {/* Create Button */}
            <PixelButton
              label={loading ? 'CREATING...' : '► CREATE & LAUNCH AI CHAT'}
              onPress={handleCreate}
              disabled={loading}
              fullWidth
            />
          </PixelCard>

          {/* Decoration */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              gap: SPACING.xs,
              marginTop: SPACING.lg,
            }}
          >
            {Array.from({ length: 12 }).map((_, i) => (
              <Text
                key={i}
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textSmall,
                  color: COLORS.primary,
                }}
              >
                ■
              </Text>
            ))}
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default NewProjectScreen;
