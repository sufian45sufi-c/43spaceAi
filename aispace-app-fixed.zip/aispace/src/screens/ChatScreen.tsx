import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, Alert, TextInput, FlatList } from 'react-native';
import { GhostMascot } from '../components/GhostMascot';
import { PixelButton } from '../components/PixelButton';
import { PixelBadge } from '../components/PixelBadge';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { useAuthStore } from '../store/authStore';
import { useProjectStore } from '../store/projectStore';
import { useMessages } from '../hooks/useMessages';
import { useSkills } from '../hooks/useSkills';
import { useSettingsStore } from '../store/settingsStore';
import { aiService } from '../services/ai.service';

interface ChatScreenProps {
  projectId: string;
  onNavigateBack: () => void;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: number;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({ projectId, onNavigateBack }) => {
  const { user } = useAuthStore();
  const { currentProject } = useProjectStore();
  const { messages, addMessage } = useMessages(projectId);
  const { allSkills, getActiveSkills } = useSkills();
  const { settings } = useSettingsStore();
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [firstMessageSent, setFirstMessageSent] = useState(false);
  const [aiStatus, setAiStatus] = useState<'ollama' | 'gemini'>('ollama');

  // Auto-send first message
  useEffect(() => {
    if (!firstMessageSent && messages.length === 0 && currentProject && user) {
      setFirstMessageSent(true);
      const sendFirstMessage = async () => {
        try {
          const activeSkills = getActiveSkills(currentProject.activeSkills);
          const firstMsg =
            'You have just been introduced to this project. Give the user a short, friendly, and practical opening analysis of their project. Mention 2-3 key things you noticed and ask one clarifying question.';

          setLoading(true);
          const response = await aiService.sendMessage(
            firstMsg,
            currentProject,
            activeSkills,
            [],
            settings
          );

          await addMessage(user.uid, 'assistant', response);
          setAiStatus('ollama');
        } catch (error) {
          if ((error as Error).message === 'NO_AI_AVAILABLE') {
            setAiStatus('gemini');
          }
          console.error('Failed to send first message:', error);
        } finally {
          setLoading(false);
        }
      };

      sendFirstMessage();
    }
  }, [firstMessageSent, messages.length, currentProject, user]);

  const handleSend = async () => {
    if (!user || !currentProject || loading || !inputText.trim()) return;

    const userMessage = inputText.trim();
    setInputText('');

    try {
      setLoading(true);

      // Add user message to Firestore
      await addMessage(user.uid, 'user', userMessage);

      // Get active skills and send to AI
      const activeSkills = getActiveSkills(currentProject.activeSkills);
      const response = await aiService.sendMessage(
        userMessage,
        currentProject,
        activeSkills,
        messages,
        settings
      );

      // Add AI response to Firestore
      await addMessage(user.uid, 'assistant', response);
      setAiStatus('ollama');
    } catch (error) {
      if ((error as Error).message === 'NO_AI_AVAILABLE') {
        setAiStatus('gemini');
        Alert.alert('AI ERROR', 'NO_AI_AVAILABLE - CONFIGURE GEMINI API KEY IN PROFILE');
      } else {
        Alert.alert('ERROR', error instanceof Error ? error.message : 'FAILED_TO_SEND_MESSAGE');
      }
    } finally {
      setLoading(false);
    }
  };

  const activeSkillCount = currentProject?.activeSkills.length || 0;

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      {/* Header */}
      <View
        style={{
          backgroundColor: COLORS.surfaceElevated,
          borderBottomWidth: 2,
          borderBottomColor: COLORS.border,
          paddingHorizontal: SPACING.md,
          paddingVertical: SPACING.md,
        }}
      >
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.sm }}>
          <Pressable onPress={onNavigateBack}>
            <Text style={{ fontFamily: FONTS.pressStart2P, fontSize: SIZES.textSmall, color: COLORS.textAccent }}>
              ←
            </Text>
          </Pressable>
          <Text
            numberOfLines={1}
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textSmall,
              color: COLORS.textPrimary,
              textTransform: 'uppercase',
              flex: 1,
              textAlign: 'center',
            }}
          >
            ◄ {currentProject?.title || 'PROJECT'} ►
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: SPACING.xs }}>
            <GhostMascot size={SIZES.ghostTiny} />
            <Text style={{ fontFamily: FONTS.pressStart2P, fontSize: SIZES.textTiny, color: COLORS.textAccent }}>
              AISPACE
            </Text>
          </View>
        </View>

        {/* AI Status Pill */}
        <PixelBadge
          label={aiStatus === 'ollama' ? '● GEMMA2 LOCAL' : '● GEMINI CLOUD'}
          bgColor={aiStatus === 'ollama' ? COLORS.accentGreen : COLORS.accentCyan}
          textColor={COLORS.bg}
        />
      </View>

      {/* Messages List */}
      <FlatList
        data={messages}
        keyExtractor={(item) => item.id}
        inverted
        contentContainerStyle={{ paddingHorizontal: SPACING.md, paddingVertical: SPACING.md }}
        renderItem={({ item }) => {
          const isUser = item.role === 'user';
          return (
            <View
              style={{
                marginBottom: SPACING.md,
                alignItems: isUser ? 'flex-end' : 'flex-start',
              }}
            >
              <View
                style={{
                  backgroundColor: isUser ? COLORS.primary : COLORS.surface,
                  borderWidth: 2,
                  borderColor: isUser ? COLORS.primary : COLORS.accentCyan,
                  borderRightWidth: 3,
                  borderBottomWidth: 3,
                  borderRightColor: isUser ? COLORS.primaryDark : COLORS.primary,
                  borderBottomColor: isUser ? COLORS.primaryDark : COLORS.primary,
                  paddingHorizontal: SPACING.md,
                  paddingVertical: SPACING.sm,
                  maxWidth: '85%',
                }}
              >
                {!isUser && (
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: SPACING.xs, marginBottom: SPACING.xs }}>
                    <GhostMascot size={SIZES.ghostTiny} />
                    <Text
                      style={{
                        fontFamily: FONTS.pressStart2P,
                        fontSize: SIZES.textTiny,
                        color: COLORS.textAccent,
                        textTransform: 'uppercase',
                      }}
                    >
                      ◄ AISPACE
                    </Text>
                  </View>
                )}
                <Text
                  style={{
                    fontFamily: FONTS.pressStart2P,
                    fontSize: SIZES.textSmall,
                    color: COLORS.textPrimary,
                    textTransform: 'uppercase',
                  }}
                >
                  {item.content}
                </Text>
              </View>
            </View>
          );
        }}
      />

      {/* Input Bar */}
      <View
        style={{
          borderTopWidth: 2,
          borderTopColor: COLORS.border,
          backgroundColor: COLORS.bg,
          paddingHorizontal: SPACING.md,
          paddingVertical: SPACING.sm,
          flexDirection: 'row',
          alignItems: 'center',
          gap: SPACING.sm,
        }}
      >
        <PixelBadge label={`🧩 ${activeSkillCount}`} bgColor={COLORS.primary} />

        <TextInput
          placeholder="TYPE COMMAND..."
          placeholderTextColor={COLORS.textMuted}
          value={inputText}
          onChangeText={setInputText}
          editable={!loading}
          style={{
            fontFamily: FONTS.pressStart2P,
            fontSize: SIZES.textSmall,
            color: COLORS.textPrimary,
            backgroundColor: COLORS.surface,
            borderWidth: 2,
            borderColor: COLORS.accentCyan,
            borderRightWidth: 3,
            borderBottomWidth: 3,
            borderRightColor: COLORS.primaryDark,
            borderBottomColor: COLORS.primaryDark,
            paddingHorizontal: SPACING.sm,
            paddingVertical: SPACING.xs,
            flex: 1,
            textTransform: 'uppercase',
          }}
        />

        <PixelButton
          label="►"
          onPress={handleSend}
          disabled={loading || !inputText.trim()}
          size="small"
        />
      </View>
    </View>
  );
};

export default ChatScreen;
