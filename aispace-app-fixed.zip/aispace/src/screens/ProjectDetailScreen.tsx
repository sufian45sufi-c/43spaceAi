import React, { useState } from 'react';
import { View, Text, ScrollView, Alert } from 'react-native';
import { GhostMascot } from '../components/GhostMascot';
import { PixelButton } from '../components/PixelButton';
import { PixelCard } from '../components/PixelCard';
import { PixelBadge } from '../components/PixelBadge';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { useProjectStore } from '../store/projectStore';
import { useMessages } from '../hooks/useMessages';
import { useSkills } from '../hooks/useSkills';
import { projectsService } from '../services/projects.service';
import { messagesService } from '../services/messages.service';
import { formatDate } from '../utils/formatDate';

interface ProjectDetailScreenProps {
  projectId: string;
  onNavigateBack: () => void;
  onNavigateToChat: () => void;
  onNavigateToSkills: () => void;
}

export const ProjectDetailScreen: React.FC<ProjectDetailScreenProps> = ({
  projectId,
  onNavigateBack,
  onNavigateToChat,
  onNavigateToSkills,
}) => {
  const { currentProject, deleteProject } = useProjectStore();
  const { messages } = useMessages(projectId);
  const { getActiveSkills } = useSkills();
  const [deleting, setDeleting] = useState(false);

  if (!currentProject) {
    return (
      <View style={{ flex: 1, backgroundColor: COLORS.bg, justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ fontFamily: FONTS.pressStart2P, fontSize: SIZES.textSmall, color: COLORS.textMuted }}>
          PROJECT NOT FOUND
        </Text>
      </View>
    );
  }

  const activeSkills = getActiveSkills(currentProject.activeSkills);

  const handleDelete = async () => {
    Alert.alert('CONFIRM', 'DELETE THIS PROJECT? THIS CANNOT BE UNDONE.', [
      { text: 'CANCEL', onPress: () => {} },
      {
        text: 'DELETE',
        onPress: async () => {
          setDeleting(true);
          try {
            // Delete all messages
            await messagesService.deleteMessagesByProject(projectId);
            // Delete project
            await projectsService.deleteProject(projectId);
            deleteProject(projectId);
            onNavigateBack();
          } catch (error) {
            Alert.alert('ERROR', error instanceof Error ? error.message : 'FAILED_TO_DELETE_PROJECT');
          } finally {
            setDeleting(false);
          }
        },
      },
    ]);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: COLORS.bg }} showsVerticalScrollIndicator={false}>
      <View style={{ paddingHorizontal: SPACING.md, paddingVertical: SPACING.lg }}>
        {/* Header */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.lg }}>
          <PixelButton label="←" onPress={onNavigateBack} size="small" />
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textSmall,
              color: COLORS.textAccent,
              textTransform: 'uppercase',
            }}
          >
            PROJECT DETAIL
          </Text>
          <Text style={{ width: 40 }} />
        </View>

        {/* Project Card */}
        <PixelCard
          bgColor={COLORS.surfaceElevated}
          borderColor={COLORS.border}
          shadowColor={COLORS.primaryDark}
          style={{ marginBottom: SPACING.lg, position: 'relative' }}
        >
          {/* Ghost in corner */}
          <View style={{ position: 'absolute', top: SPACING.sm, right: SPACING.sm }}>
            <GhostMascot size={SIZES.ghostSmall} />
          </View>

          {/* Type Badge + Date */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: SPACING.md }}>
            <PixelBadge label={currentProject.type.toUpperCase()} bgColor={COLORS.primary} />
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textMuted,
                textTransform: 'uppercase',
              }}
            >
              {formatDate(currentProject.createdAt)}
            </Text>
          </View>

          {/* Title */}
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textBody,
              color: COLORS.textPrimary,
              textTransform: 'uppercase',
              marginBottom: SPACING.sm,
            }}
          >
            {currentProject.title}
          </Text>

          {/* Description */}
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textTiny,
              color: COLORS.textMuted,
              textTransform: 'uppercase',
              marginBottom: SPACING.md,
            }}
          >
            {currentProject.description}
          </Text>

          {/* Divider */}
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textTiny,
              color: COLORS.border,
              textTransform: 'uppercase',
              marginBottom: SPACING.md,
              textAlign: 'center',
            }}
          >
            ░░░░░░░░░░░░░░░
          </Text>

          {/* Stats */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-around', gap: SPACING.md }}>
            <View style={{ alignItems: 'center' }}>
              <Text
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textSmall,
                  color: COLORS.textAccent,
                  textTransform: 'uppercase',
                }}
              >
                {new Date(currentProject.createdAt).toLocaleDateString()}
              </Text>
              <Text
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textTiny,
                  color: COLORS.textMuted,
                  textTransform: 'uppercase',
                }}
              >
                CREATED
              </Text>
            </View>

            <View style={{ alignItems: 'center' }}>
              <Text
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textSmall,
                  color: COLORS.textAccent,
                  textTransform: 'uppercase',
                }}
              >
                {messages.length}
              </Text>
              <Text
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textTiny,
                  color: COLORS.textMuted,
                  textTransform: 'uppercase',
                }}
              >
                MESSAGES
              </Text>
            </View>

            <View style={{ alignItems: 'center' }}>
              <Text
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textSmall,
                  color: COLORS.textAccent,
                  textTransform: 'uppercase',
                }}
              >
                {activeSkills.length}
              </Text>
              <Text
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textTiny,
                  color: COLORS.textMuted,
                  textTransform: 'uppercase',
                }}
              >
                SKILLS
              </Text>
            </View>
          </View>
        </PixelCard>

        {/* Active Skills */}
        {activeSkills.length > 0 && (
          <>
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textSmall,
                color: COLORS.textPrimary,
                textTransform: 'uppercase',
                marginBottom: SPACING.md,
              }}
            >
              ░ ACTIVE SKILLS ░
            </Text>

            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm, marginBottom: SPACING.lg }}>
              {activeSkills.map((skill) => (
                <PixelBadge
                  key={skill.id}
                  label={skill.name.toUpperCase()}
                  bgColor={COLORS.accentGreen}
                  textColor={COLORS.bg}
                />
              ))}
            </View>
          </>
        )}

        {/* Action Buttons */}
        <View style={{ gap: SPACING.md, marginBottom: SPACING.lg }}>
          <PixelButton label="► OPEN AI CHAT" onPress={onNavigateToChat} fullWidth />
          <PixelButton label="□ MANAGE SKILLS" onPress={onNavigateToSkills} variant="secondary" fullWidth />
        </View>

        {/* Delete Button */}
        <PixelButton
          label={deleting ? 'DELETING...' : '✕ DELETE PROJECT'}
          onPress={handleDelete}
          variant="danger"
          disabled={deleting}
          fullWidth
        />
      </View>
    </ScrollView>
  );
};

export default ProjectDetailScreen;
