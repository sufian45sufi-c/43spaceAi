import React from 'react';
import { View, Text } from 'react-native';
import { GhostMascot } from '../components/GhostMascot';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';

interface SplashScreenProps {
  onFinish?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = () => {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: COLORS.bg,
        justifyContent: 'center',
        alignItems: 'center',
        padding: SPACING.lg,
      }}
    >
      <GhostMascot size={SIZES.ghostLarge} style={{ marginBottom: SPACING.lg }} />
      <Text
        style={{
          fontFamily: FONTS.pressStart2P,
          fontSize: SIZES.textHeader,
          color: COLORS.primary,
          textTransform: 'uppercase',
        }}
      >
        AISPACE
      </Text>
      <Text
        style={{
          fontFamily: FONTS.pressStart2P,
          fontSize: SIZES.textTiny,
          color: COLORS.textMuted,
          marginTop: SPACING.sm,
          textTransform: 'uppercase',
        }}
      >
        LOADING...
      </Text>
    </View>
  );
};

export default SplashScreen;
