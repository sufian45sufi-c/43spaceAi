import React, { useState } from 'react';
import { View, Text, FlatList, ScrollView, RefreshControl } from 'react-native';
import { GhostMascot } from '../components/GhostMascot';
import { PixelButton } from '../components/PixelButton';
import { PixelCard } from '../components/PixelCard';
import { PixelBadge } from '../components/PixelBadge';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { PROJECT_TYPES, PROJECT_TYPE_EMOJIS } from '../constants/projectTypes';
import { useProjectStore } from '../store/projectStore';
import { projectsService } from '../services/projects.service';
import { useAuthStore } from '../store/authStore';
import { formatDate } from '../utils/formatDate';

interface ProjectsListScreenProps {
  onNavigateToNewProject: () => void;
  onSelectProject: (projectId: string) => void;
}

export const ProjectsListScreen: React.FC<ProjectsListScreenProps> = ({
  onNavigateToNewProject,
  onSelectProject,
}) => {
  const { user } = useAuthStore();
  const { projects, setProjects, deleteProject } = useProjectStore();
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const filteredProjects = selectedType
    ? projects.filter((p) => p.type === selectedType)
    : projects;

  const onRefresh = async () => {
    if (!user) return;
    setRefreshing(true);
    try {
      const updatedProjects = await projectsService.getProjectsByUser(user.uid);
      setProjects(updatedProjects);
    } catch (error) {
      console.error('Failed to refresh projects:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const handleDeleteProject = async (projectId: string) => {
    try {
      await projectsService.deleteProject(projectId);
      deleteProject(projectId);
    } catch (error) {
      console.error('Failed to delete project:', error);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      {/* Header */}
      <View style={{ paddingHorizontal: SPACING.md, paddingVertical: SPACING.md }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textHeader,
              color: COLORS.textAccent,
              textTransform: 'uppercase',
            }}
          >
            MY PROJECTS
          </Text>
          <PixelBadge label={`${filteredProjects.length} ACTIVE`} bgColor={COLORS.accentCyan} textColor={COLORS.bg} />
        </View>
      </View>

      {/* Filter Chips */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: SPACING.md, paddingBottom: SPACING.md, gap: SPACING.sm }}
      >
        <PixelButton
          label="ALL"
          onPress={() => setSelectedType(null)}
          variant={selectedType === null ? 'primary' : 'secondary'}
          size="small"
        />
        {PROJECT_TYPES.map((type) => (
          <PixelButton
            key={type}
            label={type.toUpperCase()}
            onPress={() => setSelectedType(type)}
            variant={selectedType === type ? 'primary' : 'secondary'}
            size="small"
          />
        ))}
      </ScrollView>

      {/* Projects List */}
      {filteredProjects.length === 0 ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: SPACING.md }}>
          <GhostMascot size={SIZES.ghostLarge} style={{ marginBottom: SPACING.lg }} />
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textSmall,
              color: COLORS.textMuted,
              textTransform: 'uppercase',
              textAlign: 'center',
            }}
          >
            NO PROJECTS FOUND
          </Text>
        </View>
      ) : (
        <FlatList
          data={filteredProjects}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: SPACING.md, paddingBottom: SPACING.lg }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          renderItem={({ item }) => (
            <PixelCard
              bgColor={COLORS.surfaceElevated}
              borderColor={COLORS.border}
              shadowColor={COLORS.primaryDark}
              style={{ marginBottom: SPACING.md }}
            >
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: SPACING.sm }}>
                <PixelBadge label={item.type.toUpperCase()} bgColor={COLORS.primary} />
                <Text
                  style={{
                    fontFamily: FONTS.pressStart2P,
                    fontSize: SIZES.textTiny,
                    color: COLORS.textMuted,
                    textTransform: 'uppercase',
                  }}
                >
                  {formatDate(item.updatedAt)}
                </Text>
              </View>

              <Text
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textSmall,
                  color: COLORS.textPrimary,
                  textTransform: 'uppercase',
                  marginBottom: SPACING.xs,
                }}
              >
                {item.title}
              </Text>

              <Text
                numberOfLines={2}
                style={{
                  fontFamily: FONTS.pressStart2P,
                  fontSize: SIZES.textTiny,
                  color: COLORS.textMuted,
                  textTransform: 'uppercase',
                  marginBottom: SPACING.md,
                }}
              >
                {item.description}
              </Text>

              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <View style={{ flexDirection: 'row', gap: SPACING.xs }}>
                  {item.activeSkills.slice(0, 3).map((skillId) => (
                    <PixelBadge key={skillId} label="●" bgColor={COLORS.accentGreen} />
                  ))}
                </View>
                <PixelButton
                  label="►"
                  onPress={() => onSelectProject(item.id)}
                  size="small"
                />
              </View>
            </PixelCard>
          )}
        />
      )}

      {/* FAB */}
      <View style={{ position: 'absolute', bottom: SPACING.lg, right: SPACING.lg }}>
        <PixelButton label="+++" onPress={onNavigateToNewProject} size="large" />
      </View>
    </View>
  );
};

export default ProjectsListScreen;
