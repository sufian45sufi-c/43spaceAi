import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, FlatList } from 'react-native';
import { GhostMascot } from '../components/GhostMascot';
import { PixelButton } from '../components/PixelButton';
import { PixelCard } from '../components/PixelCard';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { useAuthStore } from '../store/authStore';
import { useProjectStore } from '../store/projectStore';
import { projectsService } from '../services/projects.service';
import { messagesService } from '../services/messages.service';
import { Project } from '../types';
import { formatDate } from '../utils/formatDate';

interface DashboardScreenProps {
  onNavigateToProjects: () => void;
  onNavigateToNewProject: () => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  onNavigateToProjects,
  onNavigateToNewProject,
}) => {
  const { user } = useAuthStore();
  const { projects } = useProjectStore();
  const [messageCount, setMessageCount] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadStats = async () => {
      if (!user) return;
      setLoading(true);
      try {
        let totalMessages = 0;
        for (const project of projects) {
          const msgs = await messagesService.getMessagesByProject(project.id);
          totalMessages += msgs.length;
        }
        setMessageCount(totalMessages);
      } catch (error) {
        console.error('Failed to load stats:', error);
      } finally {
        setLoading(false);
      }
    };

    loadStats();
  }, [projects, user]);

  const recentProjects = projects.slice(0, 3);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: COLORS.bg }} showsVerticalScrollIndicator={false}>
      <View style={{ paddingHorizontal: SPACING.md, paddingVertical: SPACING.lg }}>
        {/* Header */}
        <Text
          style={{
            fontFamily: FONTS.pressStart2P,
            fontSize: SIZES.textHeader,
            color: COLORS.textAccent,
            textTransform: 'uppercase',
            marginBottom: SPACING.md,
          }}
        >
          WELCOME, {user?.displayName?.toUpperCase() || 'USER'}
        </Text>

        {/* Ghost Mascot */}
        <View style={{ alignItems: 'center', marginBottom: SPACING.lg }}>
          <GhostMascot size={SIZES.ghostLarge} />
        </View>

        {/* Stats Cards */}
        <View style={{ flexDirection: 'row', gap: SPACING.md, marginBottom: SPACING.lg }}>
          <PixelCard style={{ flex: 1, alignItems: 'center' }}>
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textSmall,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
              }}
            >
              {projects.length}
            </Text>
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textMuted,
                textTransform: 'uppercase',
                marginTop: SPACING.xs,
              }}
            >
              PROJECTS
            </Text>
          </PixelCard>

          <PixelCard style={{ flex: 1, alignItems: 'center' }}>
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textSmall,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
              }}
            >
              {messageCount}
            </Text>
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textMuted,
                textTransform: 'uppercase',
                marginTop: SPACING.xs,
              }}
            >
              MESSAGES
            </Text>
          </PixelCard>
        </View>

        {/* Action Buttons */}
        <View style={{ gap: SPACING.md, marginBottom: SPACING.lg }}>
          <PixelButton label="► START NEW PROJECT" onPress={onNavigateToNewProject} fullWidth />
          <PixelButton
            label="► VIEW ALL PROJECTS"
            onPress={onNavigateToProjects}
            variant="secondary"
            fullWidth
          />
        </View>

        {/* Recent Projects */}
        {recentProjects.length > 0 && (
          <>
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textSmall,
                color: COLORS.textPrimary,
                textTransform: 'uppercase',
                marginBottom: SPACING.md,
              }}
            >
              RECENT PROJECTS
            </Text>

            <FlatList
              data={recentProjects}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              renderItem={({ item }) => (
                <PixelCard
                  bgColor={COLORS.surfaceElevated}
                  borderColor={COLORS.border}
                  shadowColor={COLORS.primaryDark}
                  style={{ marginBottom: SPACING.md }}
                >
                  <Text
                    style={{
                      fontFamily: FONTS.pressStart2P,
                      fontSize: SIZES.textSmall,
                      color: COLORS.textPrimary,
                      textTransform: 'uppercase',
                      marginBottom: SPACING.xs,
                    }}
                  >
                    {item.title}
                  </Text>
                  <Text
                    style={{
                      fontFamily: FONTS.pressStart2P,
                      fontSize: SIZES.textTiny,
                      color: COLORS.textMuted,
                      textTransform: 'uppercase',
                    }}
                  >
                    {item.type} • {formatDate(item.updatedAt)}
                  </Text>
                </PixelCard>
              )}
            />
          </>
        )}
      </View>
    </ScrollView>
  );
};

export default DashboardScreen;
