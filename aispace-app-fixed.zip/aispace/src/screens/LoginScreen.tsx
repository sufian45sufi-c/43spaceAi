import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { GhostMascot } from '../components/GhostMascot';
import { PixelButton } from '../components/PixelButton';
import { PixelCard } from '../components/PixelCard';
import { PixelInput } from '../components/PixelInput';
import { COLORS, FONTS, SIZES, SPACING } from '../constants/theme';
import { authService } from '../services/auth.service';
import { useAuthStore } from '../store/authStore';

interface LoginScreenProps {
  onLoginSuccess: () => void;
  onNavigateToSignUp: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess, onNavigateToSignUp }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { setUser, setError } = useAuthStore();

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('ERROR', 'PLEASE FILL IN ALL FIELDS');
      return;
    }

    setLoading(true);
    try {
      const user = await authService.login(email, password);
      setUser(user);
      onLoginSuccess();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'LOGIN_FAILED';
      setError(errorMessage);
      Alert.alert('LOGIN ERROR', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1, backgroundColor: COLORS.bg }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: SPACING.md }}>
          {/* Ghost Mascot */}
          <GhostMascot size={SIZES.ghostMedium} style={{ marginBottom: SPACING.lg }} />

          {/* Title */}
          <Text
            style={{
              fontFamily: FONTS.pressStart2P,
              fontSize: SIZES.textHeader,
              color: COLORS.primary,
              textTransform: 'uppercase',
              marginBottom: SPACING.lg,
              textAlign: 'center',
            }}
          >
            LOGIN
          </Text>

          {/* Form Card */}
          <PixelCard
            bgColor={COLORS.surfaceElevated}
            borderColor={COLORS.accentCyan}
            shadowColor={COLORS.primaryDark}
            style={{ width: '100%', marginBottom: SPACING.lg }}
          >
            {/* Email Input */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              ◄ EMAIL
            </Text>
            <PixelInput
              placeholder="YOUR@EMAIL.COM"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              editable={!loading}
              containerStyle={{ marginBottom: SPACING.md }}
            />

            {/* Password Input */}
            <Text
              style={{
                fontFamily: FONTS.pressStart2P,
                fontSize: SIZES.textTiny,
                color: COLORS.textAccent,
                textTransform: 'uppercase',
                marginBottom: SPACING.sm,
              }}
            >
              ◄ PASSWORD
            </Text>
            <PixelInput
              placeholder="••••••••"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              editable={!loading}
              containerStyle={{ marginBottom: SPACING.lg }}
            />

            {/* Login Button */}
            <PixelButton
              label={loading ? 'LOGGING IN...' : '► LOGIN'}
              onPress={handleLogin}
              disabled={loading}
              fullWidth
            />
          </PixelCard>

          {/* Sign Up Link */}
          <PixelButton
            label="NO ACCOUNT? SIGN UP ►"
            onPress={onNavigateToSignUp}
            variant="secondary"
            disabled={loading}
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default LoginScreen;
